package com.snhu.sslserver;

import org.springframework.web.bind.annotation.*;
import javax.crypto.SecretKey;
import java.security.MessageDigest;
import java.util.Base64;

@RestController
public class CryptoController {

    private static final SecretKey secretKey;

    static {
        try {
            secretKey = AESEncryption.generateKey();
        } catch (Exception e) {
            throw new RuntimeException("Error initializing secretKey", e);
        }
    }

    @PostMapping("/encrypt")
    public String encryptData(@RequestBody String data) {
        try {
            return AESEncryption.encrypt(data, secretKey);
        } catch (Exception e) {
            e.printStackTrace();
            return "Error encrypting data: " + e.getMessage();
        }
    }

    @PostMapping("/decrypt")
    public String decryptData(@RequestBody String data) {
        try {
            return AESEncryption.decrypt(data, secretKey);
        } catch (Exception e) {
            e.printStackTrace();
            return "Error decrypting data: " + e.getMessage();
        }
    }

    @PostMapping("/generate-checksum")
    public String generateChecksum(@RequestBody String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            e.printStackTrace();
            return "Error generating checksum: " + e.getMessage();
        }
    }

    @PostMapping("/verify-checksum")
    public String verifyChecksum(@RequestBody String data, @RequestParam String checksum) {
        try {
            String generatedChecksum = generateChecksum(data);
            if (generatedChecksum.equals(checksum)) {
                return "Checksum verified successfully.";
            } else {
                return "Checksum verification failed.";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error verifying checksum: " + e.getMessage();
        }
    }

    // New endpoint to return checksum of static data
    @GetMapping("/checksum-static")
    public String checksumOfStaticData() {
        try {
            String staticData = "Hello World Check Sum!";
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(staticData.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            e.printStackTrace();
            return "Error generating checksum for static data: " + e.getMessage();
        }
    }
}
