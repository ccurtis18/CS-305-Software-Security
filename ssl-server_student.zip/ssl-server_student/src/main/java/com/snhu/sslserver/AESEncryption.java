package com.snhu.sslserver;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;


public class AESEncryption {
	
	private static final String AES = "AES";
	private static final int KEY_SIZE = 128; // Can be 128, 192, or 256 bits
	
	// Method to generate a new AES key
	 public static SecretKey generateKey() throws Exception {
		 KeyGenerator keyGenerator = KeyGenerator.getInstance(AES);
		 keyGenerator.init(KEY_SIZE);
		 
		 return keyGenerator.generateKey();
		 
	 }
	 
	// Method to encrypt a string using AES
	 public static String encrypt(String plainText, SecretKey secretKey) throws Exception {
		 Cipher cipher = Cipher.getInstance(AES);
		 cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		 byte[] encryptedBytes = cipher.doFinal(plainText.getBytes());
		 
		 return Base64.getEncoder().encodeToString(encryptedBytes);
		 
	 }
	 
	// Method to decrypt a string using AES
	 public static String decrypt(String encryptedText, SecretKey secretKey) throws Exception {
		 Cipher cipher = Cipher.getInstance(AES);
		 cipher.init(Cipher.DECRYPT_MODE, secretKey);
		 byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
		 
		 return new String(decryptedBytes);
	 }
	 
	 public static void main(String[] args) {
		 try {
			// Generate a new AES key
			SecretKey secretKey = generateKey();
			 
			// Define a string to encrypt
			String originalString = "Corvinna Curtis!";
			 
			// Encrypt the string
			String encryptedString = encrypt(originalString, secretKey);
			System.out.println("Encrypted String: " + encryptedString);
			
			// Decrypt the string
			String decryptedString = decrypt(encryptedString, secretKey);
			System.out.println("Decrypted String: " + decryptedString);
			
		 } catch (Exception e) {
			 e.printStackTrace();
		 }
	 }

}
