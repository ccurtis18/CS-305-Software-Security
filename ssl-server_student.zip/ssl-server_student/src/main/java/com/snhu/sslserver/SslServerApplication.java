package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.resource.PathResourceResolver;

import java.io.IOException;

@SpringBootApplication
public class SslServerApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    // Add the following bean to enable HTTPS and load your keystore
    @Bean
    public WebMvcConfigurer webMvcConfigurer(ResourceLoader resourceLoader) {
        return new WebMvcConfigurer() {
            @Override
            public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
                configurer.defaultContentType(MediaType.APPLICATION_JSON);
            }

            @Override
            public void addResourceHandlers(org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry registry) {
                registry.addResourceHandler("/**")
                        .addResourceLocations("classpath:/static/")
                        .resourceChain(true)
                        .addResolver(new PathResourceResolver() {
                            @Override
                            protected Resource getResource(String resourcePath, Resource location) throws IOException {
                                Resource requestedResource = location.createRelative(resourcePath);
                                if (requestedResource.exists() && requestedResource.isReadable()) {
                                    return requestedResource;
                                } else if (resourcePath.startsWith("static/")) {
                                    return new ClassPathResource("/static/index.html");
                                } else {
                                    return requestedResource;
                                }
                            }
                        });
            }
        };
    }
}
